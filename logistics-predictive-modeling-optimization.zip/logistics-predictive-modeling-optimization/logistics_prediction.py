"""
Week 4: Predictive Modeling and Optimization in Logistics Systems

Generates a reproducible synthetic shipment dataset, trains regression
models using a chronological holdout, evaluates predictions, and saves
the comparison results. All generated data is synthetic.
"""

import numpy as np
import pandas as pd

from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor, HistGradientBoostingRegressor
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler


def make_dataset(n=2400, seed=42):
    rng = np.random.default_rng(seed)
    dates = pd.date_range("2025-01-01", periods=n, freq="6h")

    distance = rng.uniform(5, 850, n)
    weight = rng.gamma(2.2, 18, n).clip(1, 180)
    traffic = rng.choice(["Low", "Medium", "High"], n,
                         p=[0.35, 0.45, 0.20])
    weather = rng.choice(["Clear", "Rain", "Severe"], n,
                         p=[0.72, 0.23, 0.05])
    vehicle = rng.choice(["Van", "Truck", "Bike"], n,
                         p=[0.45, 0.40, 0.15])
    priority = rng.choice(["Standard", "Express"], n,
                          p=[0.78, 0.22])

    hour = dates.hour.to_numpy()
    day = dates.dayofweek.to_numpy()

    traffic_delay = pd.Series(traffic).map(
        {"Low": 0, "Medium": 1.8, "High": 5.5}).to_numpy()
    weather_delay = pd.Series(weather).map(
        {"Clear": 0, "Rain": 3.5, "Severe": 10}).to_numpy()
    vehicle_effect = pd.Series(vehicle).map(
        {"Van": 1.0, "Truck": 2.5, "Bike": -0.8}).to_numpy()
    priority_effect = np.where(priority == "Express", -2.2, 0)
    peak = np.where(((hour >= 7) & (hour <= 10)) |
                    ((hour >= 16) & (hour <= 19)), 4.2, 0)
    weekend = np.where(day >= 5, -1.0, 0)
    noise = rng.normal(0, 4.5, n)

    delivery_hours = (
        0.42 + distance / 48 + weight * 0.018 + traffic_delay
        + weather_delay + vehicle_effect + priority_effect
        + peak + weekend + noise
    ).clip(0.4, None)

    return pd.DataFrame({
        "shipment_date": dates,
        "distance_km": distance,
        "weight_kg": weight,
        "traffic": traffic,
        "weather": weather,
        "vehicle_type": vehicle,
        "priority": priority,
        "hour_of_day": hour,
        "day_of_week": day,
        "delivery_hours": delivery_hours,
    }).sort_values("shipment_date").reset_index(drop=True)


def main():
    data = make_dataset()
    features = [
        "distance_km", "weight_kg", "traffic", "weather",
        "vehicle_type", "priority", "hour_of_day", "day_of_week",
    ]
    target = "delivery_hours"
    numeric = ["distance_km", "weight_kg", "hour_of_day", "day_of_week"]
    categorical = ["traffic", "weather", "vehicle_type", "priority"]

    split_index = int(len(data) * 0.80)
    train = data.iloc[:split_index]
    test = data.iloc[split_index:]

    preprocessor = ColumnTransformer([
        ("numeric", Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scale", StandardScaler()),
        ]), numeric),
        ("categorical", Pipeline([
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("onehot", OneHotEncoder(handle_unknown="ignore")),
        ]), categorical),
    ])

    models = {
        "Linear Regression": LinearRegression(),
        "Random Forest": RandomForestRegressor(
            n_estimators=250, max_depth=14, min_samples_leaf=2,
            random_state=42, n_jobs=-1,
        ),
        "HistGradientBoosting": HistGradientBoostingRegressor(
            max_iter=180, learning_rate=0.08, max_leaf_nodes=20,
            l2_regularization=1.0, random_state=42,
        ),
    }

    results = []
    for name, estimator in models.items():
        pipeline = Pipeline([
            ("preprocess", preprocessor),
            ("model", estimator),
        ])
        pipeline.fit(train[features], train[target])
        predictions = pipeline.predict(test[features])

        results.append({
            "Model": name,
            "MAE_hours": mean_absolute_error(test[target], predictions),
            "RMSE_hours": mean_squared_error(
                test[target], predictions
            ) ** 0.5,
            "R_squared": r2_score(test[target], predictions),
        })

    comparison = pd.DataFrame(results).sort_values("MAE_hours")
    comparison.to_csv("model_comparison.csv", index=False)
    data.to_csv("simulated_shipments.csv", index=False)

    print("\\nModel comparison (chronological 80/20 holdout):")
    print(comparison.to_string(index=False, float_format=lambda x: f"{x:.3f}"))
    print("\\nSaved model_comparison.csv and simulated_shipments.csv")
    print("Reminder: this is simulated academic data, not real carrier data.")


if __name__ == "__main__":
    main()
