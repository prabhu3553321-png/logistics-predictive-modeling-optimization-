# Logistics Predictive Modeling and Optimization

A Python machine-learning project that predicts shipment delivery duration using simulated logistics data and demonstrates how predictions can support dispatch and capacity decisions.

## Project contents

- `logistics_prediction.py` — generates a reproducible synthetic dataset, trains three regression models, evaluates them, and saves results.
- `requirements.txt` — Python dependencies.
- `Week_4_Logistics_Report.docx` — the written Week 4 report.

## Problem

Predict shipment delivery duration (hours) from distance, weight, traffic, weather, vehicle type, priority, dispatch hour, and day of week.

## Models

1. Linear Regression
2. Random Forest Regressor
3. Histogram-based Gradient Boosting Regressor

The script uses a chronological 80/20 train/test split and reports MAE, RMSE, and R-squared. All data is synthetic and results are for academic demonstration only.

## Run locally

```bash
python -m pip install -r requirements.txt
python logistics_prediction.py
```

The script writes `model_comparison.csv` and `simulated_shipments.csv` into the current working directory.

## Notes

This project is a demonstration, not a production delivery-time system. Replace synthetic data with properly validated operational records before using predictions for business decisions. Keep private shipment data and credentials out of public repositories.
